Welcome to the CalculatorReturnValue wiki!

10 October 2019
Changed business logic inside the calculateAnswer method so that it now correctly returns the value of:
- add
- subtract 
- Multiply 
- Divide
