Welcome to the CalculatorReturnValue wiki!
